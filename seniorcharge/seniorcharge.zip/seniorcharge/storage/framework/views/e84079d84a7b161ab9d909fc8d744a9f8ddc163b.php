<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="uft-8">
        <title>Senior Charge</title>
    </head>
    <body>
       <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\seniorcharge\seniorcharge\resources\views/layouts/app.blade.php ENDPATH**/ ?>