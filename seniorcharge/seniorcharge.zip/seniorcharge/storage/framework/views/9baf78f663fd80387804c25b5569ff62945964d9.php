<?php $__env->startSection('title','About Us'); ?>
<?php $__env->startSection('menu_about', 'active'); ?>
<?php $__env->startSection('mycontent'); ?>
<h1>About us</h1>
<div>Our website provides charging place information where the homeless people, especially the elderly homeless people can recharge their mobile device in free across Melbourne. Since we realized that the mobile device is an essential part of homeless people. Our goal is to meet homeless needs and reduce the number of the homeless people.<br>
    The user could search charging place location by simply input postcode or suburb, surrounding charging place will be displayed by list and map. The charging place maybe the public library or metro station, users could use sort by to see the ideal location. Each charging place will also be reviewed by the user to make sure the quality and availability of each place.<br>
    Homeless people need help and let us embrace them</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seniorcharge\seniorcharge\resources\views/about.blade.php ENDPATH**/ ?>