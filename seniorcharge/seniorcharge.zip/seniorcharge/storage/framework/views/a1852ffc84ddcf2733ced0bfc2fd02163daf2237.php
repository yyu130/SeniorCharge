<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!DOCTYPE html>

<?php $__env->startSection('title','Write reviews'); ?>
<?php $__env->startSection('mycontent'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">
<link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet">
<style>

    #open{
        color: green;
    }
    #close{
        color: red;
    }

    #star{
        color: #f77f00;
    }

    .Button {
        border-radius: 8px;
        padding: 7px;
        background: #588D6A;
        color: white;
        font-size: 20px;
        font-weight: bold;
        border: 1px solid grey;
        border-left: none;
        cursor: pointer;
    }

    /*.Button:hover {*/
    /*    background: forestgreen;*/
    /*}*/

    #title{
        font-weight: bold;
        color: #588D6A;
        font-size: 30px;
        font-family: Arial;
    }

    .footer{
        position: relative;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: mediumseagreen;
        color: #333333;
        text-align: center;
    }
</style>
<body style="background-color: #f0efef">
<h1></h1>
<!--<form action="/search" method="POST" role="search" class="example" style="margin-right: auto;max-width:600px">-->
<!--    <?php echo e(csrf_field()); ?>-->
<!--    <div class="input-group">-->
<!--        <input type="text" class="form-control" name="q"-->
<!--               placeholder="Search postcode/suburb here...">-->
<!--        <span>-->
<!--            <h3><b>&nbsp;Sort by&nbsp;</b></h3>-->
<!--        </span>-->
<!--        <span>-->
<!--            <select id="dropdown" class="form-control" name="sort">-->
<!--                <option value="no">No Sort By</option>-->
<!--                <option value="rating">Rating</option>-->
<!--                <option value="allDay">Only Show 24 hours</option>-->
<!--            </select>-->
<!--        </span>-->
<!--        &nbsp;-->
<!--        <span>-->
<!--            <button type="submit" id="submitBtn" class="fa fa-search">-->
<!--                <span id="search">SEARCH</span>-->
<!--            </button>-->
<!--        </span>-->
<!--    </div>-->
<!--</form>-->
<div class="container">
    <a style="color: white" href="<?php echo e(URL::previous()); ?>" class="Button"><i class="fas fa-arrow-left" > Return to map view</i></a>
</div>
<br>
<div class="container">
    <div class="row">
        <h2 id="title"><?php echo e($station->station_name); ?></h2>
    </div>
    <div class="row">
        <h5 style="font-size: 22px;font-family: Arial"><img src="<?php echo e(asset('image/pin.png')); ?>" width="15" height="15"> <?php echo e($station->address); ?> |
            <?php if(\Carbon\Carbon::now()->format('H:i:s') >= $station->mon_open & \Carbon\Carbon::now()->format('H:i:s') <= $station->mon_close): ?>
            <td><img src="<?php echo e(asset('image/clock.png')); ?>" width="15" height="15"> <b id="open">Open Now <?php echo e(\Carbon\Carbon::createFromFormat('H:i:s',$station->mon_open)->format('g:i a')); ?> - <?php echo e(\Carbon\Carbon::createFromFormat('H:i:s',$station->mon_close)->format('g:i a')); ?></b></td>
            <?php else: ?>
            <td><img src="<?php echo e(asset('image/clock.png')); ?>" width="15" height="15"> <b id="close">Closed Now </b></td>
            <?php endif; ?>
            <!--            <?php for($star = 1; $star <=5; $star++): ?>-->
            <!--            <?php if($station->star_rating >= $star): ?>-->
            <!--            <span id="star" class="glyphicon glyphicon-star"></span>-->
            <!--            <?php else: ?>-->
            <!--            <span class="glyphicon glyphicon-star-empty"></span>-->
            <!--            <?php endif; ?>-->
            <!--            <?php endfor; ?>-->
        </h5>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-5 col-md-offset-1" style="max-width: 400px">
            <!--            <h2 id="title"><?php echo e($station->station_name); ?></h2>-->
            <!--            <h5 style="font-size: 16px"><img src="<?php echo e(asset('image/pin.png')); ?>" width="15" height="15"> <?php echo e($station->address); ?> |-->
            <!--                <?php if(\Carbon\Carbon::now()->format('H:i:s') >= $station->mon_open & \Carbon\Carbon::now()->format('H:i:s') <= $station->mon_close): ?>-->
            <!--                <td><img src="<?php echo e(asset('image/clock.png')); ?>" width="15" height="15"> <b id="open">Open Now <?php echo e($station->mon_open); ?> - <?php echo e($station->mon_close); ?></b></td>-->
            <!--                <?php else: ?>-->
            <!--                <td><img src="<?php echo e(asset('image/clock.png')); ?>" width="15" height="15"> <b id="close">Close Now</b></td>-->
            <!--                <?php endif; ?>-->
            <!--            </h5>-->
            <!--            <br>-->
            <!--            <br>-->
            <!--            <br>-->
            <div class="col-md-6 col-xs-12">
                <div class="thumbnail" style="margin: auto;">
                    <?php if($station->establishment_type == "Library"): ?>
                    <img src="<?php echo e(asset('image/library.png')); ?>" width="300" height="300">
                    <?php elseif($station->establishment_type == "Housing Support Services"): ?>
                    <img src="<?php echo e(asset('image/house.png')); ?>" width="300" height="300">
                    <?php elseif($station->establishment_type == "Train Station"): ?>
                    <img src="<?php echo e(asset('image/station.png')); ?>" width="300" height="300">
                    <?php elseif($station->establishment_type == "Community Centre"): ?>
                    <img src="<?php echo e(asset('image/center.png')); ?>" width="300" height="300">
                    <?php elseif($station->establishment_type == "Community Space"): ?>
                    <img src="<?php echo e(asset('image/space.png')); ?>" width="300" height="300">
                    <?php elseif($station->establishment_type == "Restaurant"): ?>
                    <img src="<?php echo e(asset('image/mc.png')); ?>" width="300" height="300">
                    <?php else: ?>
                    <img src="<?php echo e(asset('image/other.png')); ?>" width="300" height="300">
                    <?php endif; ?>
                </div>
            </div>
            <br>
            <p style="font-family: Arial;font-size: 22px;color: #3D4738;font-weight: bold; text-align: center"><?php echo e($station->establishment_type); ?></p>
        </div>

        <div class="col-md-5 col-md-offset-1">
            <br>
            <h4 style="font-weight: bold; font-size: 28px;font-family: Arial">Facilities</h4>
            <h5 style="font-weight: bold; font-size: 22px;font-family: Arial">Types of Charger Available:<h5>
                    <?php if($station->usb_a == 1): ?>
                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/plug.png')); ?>" width="20" height="20">USB A</h5>
                    <?php endif; ?>
                    <?php if($station->usb_c == 1): ?>
                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/plug.png')); ?>" width="20" height="20">Type C</h5>
                    <?php endif; ?>
                    <?php if($station->micro_usb == 1): ?>
                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/plug.png')); ?>" width="20" height="20">Micro USB</h5>
                    <?php endif; ?>
                    <?php if($station->plug_only == 1): ?>
                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/plug.png')); ?>" width="20" height="20">Plug Only</h5>
                    <?php endif; ?>
                    <br>
                    <?php if($station->if_wifi == 1): ?>
                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/internet.png')); ?>" width="20" height="20"> Free Wifi</h5>
                    <?php endif; ?>
                    <?php if($station->if_bathroom == 1): ?>
                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/restroom.png')); ?>" width="20" height="20"> Bathroom</h5>
                    <?php endif; ?>

                    <?php if($station->access_type == "Low level of accessibility"): ?>
                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/wheelchair.png')); ?>" width="20" height="20"> Accessibility Low</h5>
                    <?php elseif(($station->access_type == "Moderate level of accessibility")): ?>
                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/wheelchair.png')); ?>" width="20" height="20"> Accessibility Moderate</h5>
                    <?php elseif(($station->access_type == "High level of accessibility")): ?>
                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/wheelchair.png')); ?>" width="20" height="20"> Accessibility High</h5>
                    <?php else: ?>
                    <h5></h5>
                    <?php endif; ?>
                    <br>
                    <!--                <?php if($station->if_wifi == 0 & $station->if_bathroom ==0 & $station->other_amenities != null): ?>-->
                    <!--                    <h5 style="font-weight: bold; font-size: 22px;font-family: Arial">Other amenities: </h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><?php echo e($station->other_amenities); ?></h5>-->
                    <!--                <?php elseif($station->if_wifi == 0 & $station->if_bathroom ==0 & $station->other_amenities == null): ?>-->
                    <!--                    <h5 style="font-weight: bold; font-size: 22px;font-family: Arial">Other amenities: </h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial">No other amenities</h5>-->
                    <!--                <?php elseif($station->if_wifi == 0 & $station->if_bathroom ==1 & $station->other_amenities == null): ?>-->
                    <!--                    <h5 style="font-weight: bold; font-size: 22px;font-family: Arial">Other amenities: </h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/restroom.png')); ?>" width="20" height="20"> Bathroom</h5>-->
                    <!--                <?php elseif($station->if_wifi == 0 & $station->if_bathroom ==1 & $station->other_amenities != null): ?>-->
                    <!--                    <h5 style="font-weight: bold; font-size: 22px;font-family: Arial">Other amenities: </h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/restroom.png')); ?>" width="20" height="20"> Bathroom </h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><?php echo e($station->other_amenities); ?></h5>-->
                    <!--                <?php elseif($station->if_wifi == 1 & $station->if_bathroom ==1 & $station->other_amenities == null): ?>-->
                    <!--                    <h5 style="font-weight: bold; font-size: 22px;font-family: Arial">Other amenities: </h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/restroom.png')); ?>" width="20" height="20"> Bathroom </h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/internet.png')); ?>" width="20" height="20"> Free Wifi</h5>-->
                    <!--                <?php elseif($station->if_wifi == 1 & $station->if_bathroom ==1 & $station->other_amenities != null): ?>-->
                    <!--                    <h5 style="font-weight: bold; font-size: 22px;font-family: Arial">Other amenities: </h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/restroom.png')); ?>" width="20" height="20"> Bathroom</h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/internet.png')); ?>" width="20" height="20"> Free Wifi</h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><?php echo e($station->other_amenities); ?></h5>-->
                    <!--                <?php elseif($station->if_wifi == 1 & $station->if_bathroom ==0 & $station->other_amenities == null): ?>-->
                    <!--                    <h5 style="font-weight: bold; font-size: 22px;font-family: Arial">Other amenities: </h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/internet.png')); ?>" width="20" height="20"> Free Wifi</h5>-->
                    <!--                <?php elseif($station->if_wifi == 1 & $station->if_bathroom ==0 & $station->other_amenities != null): ?>-->
                    <!--                    <h5 style="font-weight: bold; font-size: 22px;font-family: Arial">Other amenities: </h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><img src="<?php echo e(asset('image/internet.png')); ?>" width="20" height="20"> Free Wifi</h5>-->
                    <!--                    <h5 style="font-size: 20px;font-family: Arial"><?php echo e($station->other_amenities); ?></h5>-->
                    <!--                <?php endif; ?>-->
                    <?php if($station->other_amenities != null): ?>
                    <h5 style="font-weight: bold; font-size: 22px;font-family: Arial">Other amenities: </h5>
                    <h5 style="font-size: 20px;font-family: Arial"><?php echo e($station->other_amenities); ?></h5>

                    <?php endif; ?>

        </div>
    </div>
</div>
</div>

<div class="row">
    <div class="col-md-12">
        <br />
        <h3 aling="center">Write Reviews</h3>
        <br />

        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e(\Session::get('success')); ?></p>
        </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(url('review')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <input type="text" name="is_working" class="form-control" placeholder="Enter If charger station is working or not" />
            </div>
            <div class="form-group">
                <input type="text" name="rating" class="form-control" placeholder="Enter rating" />
            </div>
            <div class="form-group">
                <input type="text" name="is_welcoming" class="form-control" placeholder="Enter is welcoming" />
            </div>
            <div class="form-group">
                <input type="text" name="comments" class="form-control" placeholder="Enter comments" />
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" />
            </div>
        </form>
    </div>
</div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seniorcharge\seniorcharge\resources\views/writeReview.blade.php ENDPATH**/ ?>