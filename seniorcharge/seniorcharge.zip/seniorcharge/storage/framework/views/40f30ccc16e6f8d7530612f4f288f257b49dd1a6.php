<?php $__env->startSection('mycontent'); ?>
<?php if(isset(Auth::user()->email)): ?>

<body style="background-color: #f0efef">

<div class="row">
    <div class="col-md-12">
        <br />
        <h3 align="center">Edit Review</h3>
        <br />
        <?php if(count($errors) > 0): ?>

        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
            <form method="post" action="<?php echo e(action('ReviewController@update', $id)); ?>">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="PATCH" />
                <div class="form-group">
                    <input type="text" name="station_id" class="form-control" value="<?php echo e($review->station_id); ?>" placeholder="Enter Station ID" />
                </div>
                <div class="form-group">
                    <input type="text" name="is_working" class="form-control" value="<?php echo e($review->is_working); ?>" placeholder="Enter Working Status" />
                </div>
                <div class="form-group">
                    <input type="text" name="rating" class="form-control" value="<?php echo e($review->rating); ?>" placeholder="Enter Rating" />
                </div>
<!--                <div class="form-group">-->
<!--                    <input type="text" name="comments" class="form-control" value="<?php echo e($review->comments); ?>" placeholder="Enter Comments" />-->
<!--                </div>-->
                <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Edit" />
                    <a href="<?php echo e(route('review.index')); ?>" class="btn btn-primary">Back</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
<?php else: ?>
<script>window.location = "/main";</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cmsLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seniorcharge\seniorcharge\resources\views/review/edit.blade.php ENDPATH**/ ?>