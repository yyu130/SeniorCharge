<?php $__env->startSection('sidebar'); ?>
<div class='sidebar'>
    <h3>Side Bar</h3>
    This is the sidebar
    <?php echo $__env->yieldSection(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\seniorcharge\seniorcharge\resources\views/inc/sidebar.blade.php ENDPATH**/ ?>