<?php $__env->startSection('title','Detail'); ?>
<?php $__env->startSection('menu_find', 'active'); ?>
<?php $__env->startSection('mycontent'); ?>

<div class="container">
    <div class="row">

        <div class="col-md-6 col-xs-12">
            <div class="thumbnail">
                <img src="image/logo_vector.png" class="card-img">
            </div>
        </div>

        <div class="col-md-5 col-md-offset-1">
            <h2><?php echo e($station->station_name); ?></h2>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seniorcharge\seniorcharge\resources\views/station/detail.blade.php ENDPATH**/ ?>