<?php $__env->startSection('mycontent'); ?>
<?php if(isset(Auth::user()->email)): ?>
<body style="background-color: #f0efef">

<div class="row">
    <div class="col-md-12">
        <br />
        <h3 align="center">Station Data</h3>
        <br />
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <div align="right">
            <a href="<?php echo e(route('station.create')); ?>" class="btn btn-primary">Add</a>
            <br />
            <br />
        </div>
        <table class="table table-bordered table-striped">
            <tr>
                <th>Station Name</th>
                <th>Longitude</th>
                <th>latitude</th>
                <th>Address</th>
                <th>Suburb</th>
                <th>Postcode</th>
                <th>Charger Working</th>
                <th>Usb A</th>
                <th>Usb C</th>
                <th>Micro Usb</th>
                <th>Plug Only</th>
                <th>Establishment Type</th>
                <th>Wifi</th>
                <th>Bathroom</th>
                <th>Accessibility Type</th>
                <th>Other Amenities</th>
                <th>Star rating</th>
                <th>Monday Open</th>
                <th>Monday Close</th>
                <th>Tuesday Open</th>
                <th>Tuesday Close</th>
                <th>Wednesday Open</th>
                <th>Wednesday Close</th>
                <th>Thursday Open</th>
                <th>Thursday Close</th>
                <th>Friday Open</th>
                <th>Friday Close</th>
                <th>Saturday Open</th>
                <th>Saturday Close</th>
                <th>Sunday Open</th>
                <th>Sunday Close</th>
                <th>24 H</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
            <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row['station_name']); ?></td>
                <td><?php echo e($row['longitude']); ?></td>
                <td><?php echo e($row['latitude']); ?></td>
                <td><?php echo e($row['address']); ?></td>
                <td><?php echo e($row['suburb']); ?></td>
                <td><?php echo e($row['postcode']); ?></td>
                <?php if($row['if_charger_working'] == 1): ?>
                <td>Yes</td>
                <?php else: ?>
                <td>No</td>
                <?php endif; ?>
                <?php if($row['usb_a'] == 1): ?>
                <td>Yes</td>
                <?php else: ?>
                <td>No</td>
                <?php endif; ?>
                <?php if($row['usb_c'] == 1): ?>
                <td>Yes</td>
                <?php else: ?>
                <td>No</td>
                <?php endif; ?>
                <?php if($row['micro_usb'] == 1): ?>
                <td>Yes</td>
                <?php else: ?>
                <td>No</td>
                <?php endif; ?>
                <?php if($row['plug_only'] == 1): ?>
                <td>Yes</td>
                <?php else: ?>
                <td>No</td>
                <?php endif; ?>
                <td><?php echo e($row['establishment_type']); ?></td>
                <?php if($row['if_wifi'] == 1): ?>
                <td>Yes</td>
                <?php else: ?>
                <td>No</td>
                <?php endif; ?>
                <?php if($row['if_bathroom'] == 1): ?>
                <td>Yes</td>
                <?php else: ?>
                <td>No</td>
                <?php endif; ?>
                <td><?php echo e($row['access_type']); ?></td>
                <td><?php echo e($row['other_amenities']); ?></td>
                <td><?php echo e($row['star_rating']); ?></td>
                <td><?php echo e($row['mon_open']); ?></td>
                <td><?php echo e($row['mon_close']); ?></td>
                <td><?php echo e($row['tue_open']); ?></td>
                <td><?php echo e($row['tue_close']); ?></td>
                <td><?php echo e($row['wed_open']); ?></td>
                <td><?php echo e($row['wed_close']); ?></td>
                <td><?php echo e($row['thu_open']); ?></td>
                <td><?php echo e($row['thu_close']); ?></td>
                <td><?php echo e($row['fri_open']); ?></td>
                <td><?php echo e($row['fri_close']); ?></td>
                <td><?php echo e($row['sat_open']); ?></td>
                <td><?php echo e($row['sat_close']); ?></td>
                <td><?php echo e($row['sun_open']); ?></td>
                <td><?php echo e($row['sun_close']); ?></td>
                <?php if($row['if_24h'] == 1): ?>
                <td>Yes</td>
                <?php else: ?>
                <td>No</td>
                <?php endif; ?>

                <td><a href="<?php echo e(action('StationController@edit', $row['id'])); ?>" class="btn btn-warning">Edit</a></td>
                <td>
                    <form method="post" class="delete_form" action="<?php echo e(action('StationController@destroy', $row['id'])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="DELETE" />
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($stations->links()); ?>


    </div>
</div>
<script>
    $(document).ready(function(){
        $('.delete_form').on('submit', function(){
            if(confirm("Are you sure you want to delete it?"))
            {
                return true;
            }
            else
            {
                return false;
            }
        });
    });
</script>
</body>
<?php else: ?>
<script>window.location = "/main";</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('cmsLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seniorcharge\seniorcharge\resources\views/station/index.blade.php ENDPATH**/ ?>