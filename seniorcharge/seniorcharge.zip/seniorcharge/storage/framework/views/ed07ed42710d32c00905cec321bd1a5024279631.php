<?php $__env->startSection('title','Contact Us'); ?>
<?php $__env->startSection('menu_contact', 'active'); ?>
<?php $__env->startSection('mycontent'); ?>
<h1>Contact Us</h1>
<div>contact us</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seniorcharge\seniorcharge\resources\views/contact.blade.php ENDPATH**/ ?>