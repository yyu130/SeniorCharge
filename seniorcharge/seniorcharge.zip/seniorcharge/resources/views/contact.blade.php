@extends('layout')
@section('title','Contact Us')
@section('menu_contact', 'active')
@section('mycontent')
<h1>Contact Us</h1>
<div>contact us</div>
@endsection
