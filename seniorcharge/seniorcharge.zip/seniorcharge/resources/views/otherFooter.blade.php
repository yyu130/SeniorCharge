<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .footer{
            position: relative;
            left: 0;
            bottom: 0;
            width: 100%;
            background-color: #85b892;
            color: white;
            text-align: center;
        }
    </style>
</head>
<body>
<div class="footer">
    @ 2020 Sr.Charge. All Rights Reserved * <a href="/attribution" style="color: white">Attributions</a>
</div>
</body>
</html>
